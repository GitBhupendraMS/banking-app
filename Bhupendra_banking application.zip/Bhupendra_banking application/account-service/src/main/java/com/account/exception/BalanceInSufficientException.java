package com.account.exception;

public class BalanceInSufficientException extends SimpleBankingGlobalException {
    public BalanceInSufficientException() {
        super("You are not having sufficient balance", GlobalErrorCode.ERROR_USER_NOT_HAVING_SUFFICIENT_BALANCE);
    }

    public BalanceInSufficientException (String message) {
        super(message, GlobalErrorCode.ERROR_USER_NOT_HAVING_SUFFICIENT_BALANCE);
    }
}
