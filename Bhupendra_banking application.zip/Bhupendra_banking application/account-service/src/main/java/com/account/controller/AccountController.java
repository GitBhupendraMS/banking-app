package com.account.controller;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.account.model.dto.Account;
import com.account.model.dto.AccountDepositRequest;
import com.account.model.dto.AccountWithdrawRequest;
import com.account.service.AccountService;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping(path = "/api/v1/account")
@Slf4j
public class AccountController {


	@Autowired
   private AccountService accountService;
    
	@ApiOperation(value = "Open new account")
    @PostMapping(value = "/openAccount")
    public ResponseEntity<Account> createAccount(@RequestBody Account request) {

        return ResponseEntity.ok(accountService.openAccount(request));
    }

	
	@ApiOperation(value = "Deposit request")
    @PostMapping(value = "/deposit")
    public ResponseEntity<String> deposit(@RequestBody AccountDepositRequest depositRequest) {

        return ResponseEntity.ok(accountService.deposit(depositRequest));
    }

	@ApiOperation(value = "Withdraw request")
    @PostMapping(value = "/withdraw")
    public ResponseEntity<String> withdraw(@RequestBody AccountWithdrawRequest withdrawRequest) {

        return ResponseEntity.ok(accountService.withdraw(withdrawRequest));
    }
	
	@ApiOperation(value = "Balance Enquiry")
    @GetMapping(value = "/{accountNumber}/getBalance")
    public ResponseEntity<Double> getBalance(@PathVariable("accountNumber") Long accountNumber) {

        return ResponseEntity.ok(accountService.getBalance(accountNumber));
    }
	
	@ApiOperation(value = "Get Account details Enquiry")
    @GetMapping(value = "/{accountNumber}")
    public ResponseEntity<Account> getAccount(@PathVariable("accountNumber") Long accountNumber) {

        return ResponseEntity.ok(accountService.getAccount(accountNumber));
    }
	
	@ApiOperation(value = "Update account")
    @PutMapping(value = "/")
    public ResponseEntity<Account> updateAccount(@RequestBody Account request) {

        return ResponseEntity.ok(accountService.updateAccount(request));
    }
	

}
