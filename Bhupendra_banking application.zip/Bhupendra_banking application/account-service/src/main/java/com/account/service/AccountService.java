package com.account.service;

import org.springframework.stereotype.Service;

import com.account.model.dto.Account;
import com.account.model.dto.AccountDepositRequest;
import com.account.model.dto.AccountWithdrawRequest;
import com.account.model.entity.AccountEntity;


public interface AccountService {

	/**
	 * To open a new account
	 * @param account
	 * @return
	 */
	public Account openAccount(Account account);

	/**
	 * To deposit amount on given account
	 * @param depositRequest
	 * @return
	 */
	public String deposit(AccountDepositRequest depositRequest);

	/**
	 * To withdraw the amount from given account
	 * @param withdrawRequest
	 * @return
	 */
	public String withdraw(AccountWithdrawRequest withdrawRequest);

	/**
	 * To return balance
	 * @param accountNumber
	 * @return
	 */
	public Double getBalance(Long accountNumber);

	/**
	 * To get account details
	 * @param accountNumber
	 * @return
	 */
	public Account getAccount(Long accountNumber);

	/**
	 * To update a account
	 * @param account
	 * @return
	 */
	public Account updateAccount(Account account);
}
