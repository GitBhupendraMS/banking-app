package com.account.service.impl;

import java.security.SecureRandom;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.account.exception.BalanceInSufficientException;
import com.account.exception.EntityNotFoundException;
import com.account.model.dto.Account;
import com.account.model.dto.AccountDepositRequest;
import com.account.model.dto.AccountWithdrawRequest;
import com.account.model.entity.AccountEntity;
import com.account.model.repository.AccountRepository;
import com.account.service.AccountService;
import com.account.utils.ObjectMapperUtils;

@Service
public class AccountServiceImpl implements AccountService {

	
	@Autowired
	private AccountRepository accountRepository;
	
	private final SecureRandom secureRandom = new SecureRandom();
	
	@Override
	public Account openAccount(Account account) {
		
		//Need to add logic to add unique account number
		//account.setAccountNumber(null);
		Long uniqueAccountNumber = secureRandom.nextLong(1001, 9999999999L);
		account.setAccountNumber(uniqueAccountNumber);
		
		AccountEntity entity = ObjectMapperUtils.map(account, AccountEntity.class);
				
		return ObjectMapperUtils.map(accountRepository.save(entity), Account.class);
	}

	@Override
	public String deposit(AccountDepositRequest depositRequest) {
		
		AccountEntity accountEntity = accountRepository.findByAccountNumber(depositRequest.getAccountNumber()).orElseThrow(EntityNotFoundException::new);
		
		accountEntity.setBalance(accountEntity.getBalance() + depositRequest.getAmount());
		
		accountRepository.save(accountEntity);
		
		return "Amount deposited successfully";
	}

	@Override
	public String withdraw(AccountWithdrawRequest withdrawRequest) {
		
		AccountEntity accountEntity = accountRepository.findByAccountNumber(withdrawRequest.getAccountNumber()).orElseThrow(EntityNotFoundException::new);
		
		if(withdrawRequest.getAmount() > accountEntity.getBalance()) {
			throw new BalanceInSufficientException();
		}
		accountEntity.setBalance(accountEntity.getBalance() - withdrawRequest.getAmount());
		
		accountRepository.save(accountEntity);
		
		return "Amount withdrawal successfully";
		
	}

	@Override
	public Double getBalance(Long accountNumber) {
		AccountEntity accountEntity = accountRepository.findByAccountNumber(accountNumber).orElseThrow(EntityNotFoundException::new);
		
		return accountEntity.getBalance();
	}

	@Override
	public Account getAccount(Long accountNumber) {
		
		AccountEntity accountEntity = accountRepository.findByAccountNumber(accountNumber).orElseThrow(EntityNotFoundException::new);
		
		
		return ObjectMapperUtils.map(accountEntity, Account.class);
		
	}
	
	@Override
	public Account updateAccount(Account account) {
		
		AccountEntity entity = ObjectMapperUtils.map(account, AccountEntity.class);
		
		return ObjectMapperUtils.map(accountRepository.save(entity), Account.class);
		
	}

}
