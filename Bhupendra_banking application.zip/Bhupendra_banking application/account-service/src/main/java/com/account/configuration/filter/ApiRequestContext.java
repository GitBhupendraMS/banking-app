package com.account.configuration.filter;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApiRequestContext {
    private String authId;
}
