package com.notification.service.impl;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.stereotype.Service;

import com.notification.model.Notification;
import com.notification.service.NotificationService;

@Service
public class NotificationServiceImpl implements NotificationService {

	@Override
	public String sendNotification(Notification notification) {
				
		 String username = "lakhanram365@gmail.com"; // set from email id
         String password = "mddg syfd wksf ycpw"; //set app password

        Properties props = new Properties();
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props,
          new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
          });

        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("lakhanram365@gmail.com"));
            message.setRecipients(Message.RecipientType.TO,
                InternetAddress.parse(notification.getToEmail()));
            message.setSubject(notification.getSubject());
            message.setText(notification.getContent());

            Transport.send(message);

        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }
		return "Notification sent successful";
	}

}
