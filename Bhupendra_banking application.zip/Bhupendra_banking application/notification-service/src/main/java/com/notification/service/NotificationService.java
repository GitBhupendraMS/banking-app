package com.notification.service;

import com.notification.model.Notification;

public interface NotificationService {

	/**
	 * To trigger a email notification
	 * @param notification
	 * @return
	 */
	public String sendNotification(Notification notification);
}

