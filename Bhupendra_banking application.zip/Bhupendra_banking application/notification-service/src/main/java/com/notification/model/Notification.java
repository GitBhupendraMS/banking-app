package com.notification.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class Notification implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3338376678894240769L;
	
	private String toEmail;
	
	private String subject;
	
	private String content;

	public String getToEmail() {
		return toEmail;
	}

	public void setToEmail(String toEmail) {
		this.toEmail = toEmail;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
	
	

}
