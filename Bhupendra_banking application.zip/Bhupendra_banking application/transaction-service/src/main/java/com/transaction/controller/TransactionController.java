package com.transaction.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.transaction.model.dto.Transaction;
import com.transaction.model.dto.request.FundTransferRequest;
import com.transaction.model.dto.response.FundTransferResponse;
import com.transaction.service.TransactionService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping(path = "/api/v1/transaction")
@Slf4j
public class TransactionController {

	@Autowired
	private TransactionService transactionService;
	
	@PostMapping("/fund-transfer")
    public ResponseEntity<FundTransferResponse> fundTransfer(@RequestBody FundTransferRequest fundTransferRequest) {
//        log.info("Fund transfer initiated in core bank from {}", fundTransferRequest.toString());
        return ResponseEntity.ok(transactionService.fundTransfer(fundTransferRequest));
    }
	
	@GetMapping("/transaction/{accountNumber}")
	public ResponseEntity<List<Transaction>> getAllTransaction(@PathVariable("accountNumber") Long accountNumber) {
		
		return ResponseEntity.ok(transactionService.getAllTransaction(accountNumber));
	}
	
}
