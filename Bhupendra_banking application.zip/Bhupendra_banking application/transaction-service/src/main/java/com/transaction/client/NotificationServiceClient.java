package com.transaction.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.transaction.client.bo.Notification;


@FeignClient(name = "notification-service", url = "http://localhost:9011/api/v1/notification")
public interface NotificationServiceClient {
	
	@PostMapping(value = "/sendNotification")
    public ResponseEntity<String> sendNotification(@RequestBody Notification request);

}
