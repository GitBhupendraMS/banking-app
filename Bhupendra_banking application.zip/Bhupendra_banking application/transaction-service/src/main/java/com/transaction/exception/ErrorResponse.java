package com.transaction.exception;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class ErrorResponse {
    
	private String code;
    private String message;
	
    
    
    public ErrorResponse(String code2, String message2) {
		// TODO Auto-generated constructor stub
    	this.code = code2;
    	this.message = message2;
	}
}
