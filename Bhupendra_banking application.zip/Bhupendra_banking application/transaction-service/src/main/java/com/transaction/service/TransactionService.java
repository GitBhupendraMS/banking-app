package com.transaction.service;

import java.util.List;

import com.transaction.model.dto.Transaction;
import com.transaction.model.dto.request.FundTransferRequest;
import com.transaction.model.dto.response.FundTransferResponse;

public interface TransactionService {

	/**
	 * To transfer fund
	 * @param fundTransferRequest
	 * @return
	 */
	public FundTransferResponse fundTransfer(FundTransferRequest fundTransferRequest);
	
	/**
	 * To return all transaction of given account
	 * @param accountNumber
	 * @return
	 */
	public List<Transaction> getAllTransaction(Long accountNumber);

}
