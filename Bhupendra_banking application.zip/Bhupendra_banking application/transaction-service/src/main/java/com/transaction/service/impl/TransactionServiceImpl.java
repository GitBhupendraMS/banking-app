package com.transaction.service.impl;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.transaction.client.AccountServiceClient;
import com.transaction.client.NotificationServiceClient;
import com.transaction.client.bo.Account;
import com.transaction.client.bo.Notification;
import com.transaction.exception.BalanceInSufficientException;
import com.transaction.exception.GlobalErrorCode;
import com.transaction.model.dto.Transaction;
import com.transaction.model.dto.request.FundTransferRequest;
import com.transaction.model.dto.response.FundTransferResponse;
import com.transaction.model.entity.TransactionEntity;
import com.transaction.model.repository.TransactionRepository;
import com.transaction.service.TransactionService;
import com.transaction.utils.ObjectMapperUtils;

@Service
public class TransactionServiceImpl implements TransactionService {

	@Autowired
	private AccountServiceClient accountServiceClient;
	
	@Autowired
	private TransactionRepository transactionRepository;
	
	@Autowired
	private NotificationServiceClient notificationServiceClient;
	
	@Override
	public FundTransferResponse fundTransfer(FundTransferRequest fundTransferRequest) {
		Account fromBankAccount = accountServiceClient.getAccount(fundTransferRequest.getFromAccount()).getBody();
        Account toBankAccount = accountServiceClient.getAccount(fundTransferRequest.getToAccount()).getBody();

        //validating account balances
        validateBalance(fromBankAccount, fundTransferRequest.getAmount());

        String transactionId = internalFundTransfer(fromBankAccount, toBankAccount, fundTransferRequest.getAmount());
        
        FundTransferResponse fundTransferResponse = new FundTransferResponse();
        fundTransferResponse.setTransactionId(transactionId);
        fundTransferResponse.setMessage("Transaction successfully completed");
        
        return fundTransferResponse;
	}
	
	
	private void validateBalance(Account bankAccount, Double amount) {
        if (bankAccount.getBalance() < 0 || bankAccount.getBalance() < amount) {
            throw new BalanceInSufficientException("Insufficient funds in the account " + bankAccount.getAccountNumber());
        }
    }

    public String internalFundTransfer(Account fromBankAccount, Account toBankAccount, Double amount) {

        String transactionId = UUID.randomUUID().toString();

        fromBankAccount.setBalance(fromBankAccount.getBalance() -amount);
        accountServiceClient.updateAccount(fromBankAccount);

        TransactionEntity transactionEntity = new TransactionEntity();
        transactionEntity.setAmount(amount);
        transactionEntity.setFromAccountNumber(fromBankAccount.getAccountNumber());
        transactionEntity.setToAccountNumber(toBankAccount.getAccountNumber());
        transactionEntity.setTransactionType("Debit");
        transactionEntity.setTransactionId(transactionId);
        
        transactionRepository.save(transactionEntity);
        
        Notification notification = new Notification();
        notification.setToEmail(fromBankAccount.getEmail());
        notification.setSubject("Your transaction is successful");
        String content = "Your transaction with ref no "+ transactionId +" for Rs. " + amount + " has been credited to beneficiary : " +
        		" " + toBankAccount.getName() + " on " + new Date().toString();
        notification.setContent(content);
        notificationServiceClient.sendNotification(notification);

        toBankAccount.setBalance(toBankAccount.getBalance() + amount);
        
        accountServiceClient.updateAccount(toBankAccount);

        TransactionEntity transactionEntity1 = new TransactionEntity();
        transactionEntity1.setAmount(amount);
        transactionEntity1.setFromAccountNumber(toBankAccount.getAccountNumber());
        transactionEntity1.setToAccountNumber(fromBankAccount.getAccountNumber());
        transactionEntity1.setTransactionType("Credit");
        transactionEntity1.setTransactionId(transactionId);
        
        transactionRepository.save(transactionEntity1);
        
        notification.setToEmail(toBankAccount.getEmail());
        notification.setSubject("Credit Alert");
        content = "Your account credited " + amount + " on " +  new Date().toString();
        		
        notification.setContent(content);
        notificationServiceClient.sendNotification(notification);

        return transactionId;

    }


	@Override
	public List<Transaction> getAllTransaction(Long accountNumber) {
		
		 List<TransactionEntity> entities =  transactionRepository.findAllByFromAccountNumber(accountNumber);
		return ObjectMapperUtils.mapAll(entities, Transaction.class);
	}


}
