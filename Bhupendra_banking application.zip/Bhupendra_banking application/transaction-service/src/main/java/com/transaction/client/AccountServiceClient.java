package com.transaction.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.transaction.client.bo.Account;


@FeignClient(name = "account-service", url = "http://localhost:9009/api/v1/account/")
public interface AccountServiceClient {

	
	@GetMapping(value = "/{accountNumber}")
    public ResponseEntity<Account> getAccount(@PathVariable("accountNumber") Long accountNumber);
    
	@PutMapping(value = "/")
    public ResponseEntity<Account> updateAccount(@RequestBody Account request);
}
